package org.example.services;

import org.example.models.Envio;
import java.util.Date;

public class ServicioEnvio {

    public Envio crearEnvio(Date fechaEnvio, String transporte, int pesoMerca, int costoEnvio,int distanciaEnvio){
        if (pesoMerca == -100 || pesoMerca == 100.50){
            System.out.println("no se puede crear un envío con números negativos ni decimal");
            return null;
        }
        if (distanciaEnvio == -600 || distanciaEnvio == 600.50) {
            System.out.println("");
        }


        return null;
    }
}


