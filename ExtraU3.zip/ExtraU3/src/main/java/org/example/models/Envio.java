package org.example.models;

import java.util.Date;

public class Envio {
    private int numEnvio;
    private Date fechaEnvio;
    private String transporte;
    private int pesoMerca;
    private int costoEnvio;
    public int distanciaEnvio;


    public Envio(int numEnvio) {
        this.numEnvio = numEnvio;
    }

    public int getNumEnvio() {
        return numEnvio;
    }

    public void setNumEnvio(int numEnvio) {
        this.numEnvio = numEnvio;
    }

    public Date getFechaEnvio() {
        return fechaEnvio;
    }

    public void setFechaEnvio(Date fechaEnvio) {
        this.fechaEnvio = fechaEnvio;
    }

    public String getTransporte() {
        return transporte;
    }

    public void setTransporte(String transporte) {
        this.transporte = transporte;
    }

    public int getPesoMerca() {
        return pesoMerca;
    }

    public void setPesoMerca(int pesoMerca) {
        this.pesoMerca = pesoMerca;
    }

    public int getCostoEnvio() {
        return costoEnvio;
    }

    public void setCostoEnvio(int costoEnvio) {
        this.costoEnvio = costoEnvio;
    }

    public int getDistanciaEnvio() {
        return distanciaEnvio;
    }

    public void setDistanciaEnvio(int distanciaEnvio) {
        this.distanciaEnvio = distanciaEnvio;
    }
}
