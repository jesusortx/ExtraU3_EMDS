package org.example.services;

import org.example.models.Envio;
import org.junit.Test;

import static org.junit.Assert.*;

public class ServicioEnvioTest {
    @Test
    public void testCaso1(){
        Envio envioPrueba= new Envio();
        envioPrueba.setPesoMerca(-100);
        envioPrueba.setCostoEnvio(50);
        envioPrueba.setDistanciaEnvio(200);
        envioPrueba.setTransporte("Terestre");
        assertEquals("Envio creado correctamente",
                "no se puede crear un envío con números negativos ni decimal");
    }

}